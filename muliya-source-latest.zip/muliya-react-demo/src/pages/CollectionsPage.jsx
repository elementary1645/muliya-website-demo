import { Link } from "react-router-dom";
import {
  ArrowRight,
  Crown,
  Gem,
  Heart,
  Sparkles,
  Star,
} from "lucide-react";

const collections = [
  {
    name: "Bridal Collection",
    slug: "Bridal",
    description:
      "Statement jewellery designed for weddings, receptions and traditional celebrations.",
    icon: Crown,
  },
  {
    name: "Wedding Collection",
    slug: "Wedding",
    description:
      "Elegant gold and diamond pieces curated for every wedding ceremony.",
    icon: Heart,
  },
  {
    name: "Temple Collection",
    slug: "Temple",
    description:
      "Traditional designs inspired by heritage motifs and classical craftsmanship.",
    icon: Sparkles,
  },
  {
    name: "Everyday Collection",
    slug: "Everyday",
    description:
      "Lightweight and versatile jewellery designed for daily wear.",
    icon: Star,
  },
  {
    name: "Luxury Collection",
    slug: "Luxury",
    description:
      "Premium jewellery featuring refined details, precious stones and bold designs.",
    icon: Gem,
  },
  {
    name: "Modern Collection",
    slug: "Modern",
    description:
      "Contemporary jewellery with clean lines, minimal styling and modern appeal.",
    icon: Sparkles,
  },
  {
    name: "Traditional Collection",
    slug: "Traditional",
    description:
      "Timeless jewellery inspired by Indian culture, festivals and family traditions.",
    icon: Crown,
  },
  {
    name: "Men's Collection",
    slug: "Men",
    description:
      "Chains, rings, bracelets and statement pieces designed for men.",
    icon: Gem,
  },
  {
    name: "Kids Collection",
    slug: "Kids",
    description:
      "Playful, lightweight and comfortable jewellery created for children.",
    icon: Star,
  },
  {
    name: "Festive Collection",
    slug: "Festive",
    description:
      "Celebration-ready jewellery for festivals, family occasions and special moments.",
    icon: Sparkles,
  },
];

function CollectionsPage() {
  return (
    <main className="collections-page">
      <section className="collections-hero">
        <div className="container collections-hero-content">
          <p className="section-eyebrow">Curated Jewellery</p>

          <h1>Discover Our Collections</h1>

          <p>
            Explore jewellery created for weddings, celebrations, everyday
            elegance and unforgettable moments.
          </p>

          <Link to="/products" className="primary-button">
            View All Jewellery
            <ArrowRight size={18} aria-hidden="true" />
          </Link>
        </div>
      </section>

      <section className="collections-section">
        <div className="container">
          <div className="section-heading">
            <div>
              <p className="section-eyebrow">Explore by Style</p>
              <h2>Collections for Every Occasion</h2>
            </div>

            <p>
              Select a collection to browse matching jewellery from the live
              product catalogue.
            </p>
          </div>

          <div className="collections-grid">
            {collections.map((collection) => {
              const Icon = collection.icon;

              return (
                <article
                  key={collection.slug}
                  className="collection-card"
                >
                  <div
                    className="collection-card-icon"
                    aria-hidden="true"
                  >
                    <Icon size={28} />
                  </div>

                  <div className="collection-card-content">
                    <h3>{collection.name}</h3>

                    <p>{collection.description}</p>

                    <Link
                      to={`/products?collection=${encodeURIComponent(
                        collection.slug,
                      )}`}
                      className="collection-card-link"
                    >
                      Explore Collection
                      <ArrowRight size={17} aria-hidden="true" />
                    </Link>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section className="collections-feature-section">
        <div className="container collections-feature-grid">
          <div className="collections-feature-content">
            <p className="section-eyebrow">Find Your Style</p>

            <h2>Not Sure Which Collection Suits You?</h2>

            <p>
              Upload a jewellery image and use our AI image search to discover
              visually similar products from the catalogue.
            </p>

            <div className="collections-feature-actions">
              <Link to="/image-search" className="primary-button">
                Try AI Image Search
                <ArrowRight size={18} aria-hidden="true" />
              </Link>

              <Link to="/appointment" className="secondary-button">
                Speak to an Expert
              </Link>
            </div>
          </div>

          <div className="collections-feature-panel">
            <div>
              <Gem size={42} aria-hidden="true" />
              <h3>Personal Jewellery Assistance</h3>
              <p>
                Book an appointment at your preferred showroom and receive
                personalised recommendations from our jewellery experts.
              </p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}

export default CollectionsPage;